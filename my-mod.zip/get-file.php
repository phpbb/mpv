<?
	// Haiz!

	$test = $_GET['test'];


	print $_POST['file'];

	print request_var('bla', "0");

	print request_var('bla', '1');

	if (isset($_POST['bla']))
	{

	}
?>

<?= $_FILES['tmp']['temp_name']; ?>