<?
	// Haiz!
	mysql_connect();
	
	$function = new mysql_blabla(); // should not trigger.
?>