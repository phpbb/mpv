<?php
/**
 * This is a comment
 * really
 * and this comments include
 * a include
 * so this is a test
 * to make sure mpv does not print this
 * really ;)
 */include 'bla_poging1.php';
include 'bla_poging2.php';
// And here is another include ('test') test
include 'bla_poging3.php';
include 'bla_poging4.php';/*
                           *
                           * blabla
                           */
include 'bla_poging5.php';
?>