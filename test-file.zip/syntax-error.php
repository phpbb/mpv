<?php

echo 'this is a error'

echo 'iam a error';

?>
