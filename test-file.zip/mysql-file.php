<?
	// Haiz!
	mysql_connect();
?>