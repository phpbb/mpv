<?php
	// Haiz!
    include ("test.php");

	include ("test.$phpEx");

	include ("{$phpbb_root_path}test.php");

	include ("{$phpbb_root_path}test.$phpEx");

    require ("test.php");

    require ("test.$phpEx");

    require ("{$phpbb_root_path}test.php");

    require ("{$phpbb_root_path}test.$phpEx");
?>