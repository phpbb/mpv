<?php
$bla = 'mysql_40'; // Should not triggr.
$bla = `bla`;
$bla = eval($bla);
$bla = exec($bla);
$bla = system($bla);
$bla = passthru($bla);
$bla = getenv('TEST');
die();
exit(); // Should not trigger.
$bla = md5($bla);
$bla = sha1($bla);
$bla = addslashes($bla);
$bla = stripslashes($bla);
include_once($bla);
require_once($bla);

// This should also trigger something, including spaces there
$bla = md5                  ($bla); // Tabs
$bla = md5   ($bla) // Spaces

?>